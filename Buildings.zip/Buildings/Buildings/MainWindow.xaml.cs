﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.VisualBasic;
using System.Text;
using System.Linq;

namespace Buildings
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private BuildingContext dbContext = new BuildingContext();

        public MainWindow()
        {
            InitializeComponent();
            LoadData();
        }

        // Метод для загрузки данных без фильтрации или сортировки
        public void LoadData()
        {
            var sales = dbContext.Sales
                .Include(s => s.TypeOfStructureNavigation)
                .ToList();

            DtgSale.ItemsSource = sales;

            
            CmbFiltr.ItemsSource = dbContext.Structures.ToList();
            CmbFiltr.SelectedIndex = -1;

        }

        // Метод для поиска по введенному тексту
        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchText = TxtSearch.Text.ToLower().Trim();

            if (string.IsNullOrWhiteSpace(searchText))
            {
                LoadData();
                return;
            }

            var filteredSales = dbContext.Sales
                .Include(s => s.TypeOfStructureNavigation)
                .Where(s =>
                    (s.TypeOfStructureNavigation != null &&
                     s.TypeOfStructureNavigation.TypeOfStructure != null &&
                     s.TypeOfStructureNavigation.TypeOfStructure.ToLower().Contains(searchText)) ||
                    s.NumOfRooms.ToString().Contains(searchText) ||
                    s.Footage.ToString().Contains(searchText) ||
                    s.Price.ToString().Contains(searchText)
                )
                .ToList();

            DtgSale.ItemsSource = filteredSales;

            if (filteredSales.Count == 0)
            {
                MessageBox.Show("Товары не найдены.");
            }
        }



        // Сортировка по возрастанию
        private void BtnSortUp_Click(object sender, RoutedEventArgs e)
        {
            var sortedSales = dbContext.Sales
                .Include(s => s.TypeOfStructureNavigation)
                .OrderBy(s => s.Price)
                .ToList();

            DtgSale.ItemsSource = sortedSales;
        }

        // Сортировка по убыванию
        private void BtnSortDown_Click(object sender, RoutedEventArgs e)
        {
            var sortedSales = dbContext.Sales
                .Include(s => s.TypeOfStructureNavigation)
                .OrderByDescending(s => s.Price)
                .ToList();

            DtgSale.ItemsSource = sortedSales;
        }

        // Обработчик для изменения выбранного типа структуры в ComboBox
        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedItem is Structure selectedStructure)
            {
                var filteredSales = dbContext.Sales
                    .Include(s => s.TypeOfStructureNavigation)
                    .Where(s => s.TypeOfStructure == selectedStructure.IdBuilding)
                    .ToList();

                DtgSale.ItemsSource = filteredSales;
            }
            else
            {
                
                LoadData();
            }
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            TxtSearch.Clear();
            CmbFiltr.SelectedIndex = -1;
            LoadData();
        }

    }
}