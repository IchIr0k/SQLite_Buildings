﻿using System;
using System.Collections.Generic;

namespace Building;

public partial class Build
{
    public int IdBuild { get; set; }

    public string? TypeBuild { get; set; }

    public virtual ICollection<Itog> Itogs { get; set; } = new List<Itog>();
}
