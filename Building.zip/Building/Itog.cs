﻿using System;
using System.Collections.Generic;

namespace Building;

public partial class Itog
{
    public int Id { get; set; }

    public int Build { get; set; }

    public int CountRooms { get; set; }

    public double Footage { get; set; }

    public double Price { get; set; }

    public virtual Build BuildNavigation { get; set; } = null!;
}
