﻿using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Building
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly BuildsContext _context = new BuildsContext();
        public MainWindow()
        {
            InitializeComponent();

            CmbFiltr.ItemsSource = _context.Builds.ToList();
            
            CmbFiltr.DisplayMemberPath = "TypeBuild";
            LoadData();
        }
        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedItem is Build selectedBuild)
            {
                var filtered = _context.Itogs
                    .Include(i => i.BuildNavigation)
                    .Where(i => i.Build == selectedBuild.IdBuild)
                    .ToList();

                BuildDataGrid.ItemsSource = filtered;
            }
        }


        private void LoadData()
        {
            
                var build = _context.Itogs
                    .Include(c => c.BuildNavigation)
                    .ToList();

                BuildDataGrid.ItemsSource = build;
            
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            var searchText = TxtSearch.Text.ToLower();

            var build = _context.Itogs
                .Include(c => c.BuildNavigation)
                .Where(p => p.BuildNavigation.TypeBuild != null &&
                            p.BuildNavigation.TypeBuild.ToLower().Contains(searchText))
                .ToList();

            if (build.Count == 0)
            {
                MessageBox.Show("Такого строения нет");
            }

            BuildDataGrid.ItemsSource = build;
        }




        private void BtnSortUp_Click(object sender, RoutedEventArgs e)
        {
            var build = _context.Itogs
                       .Include(c => c.BuildNavigation).
                       OrderBy(p=>p.Price).ToList();
            BuildDataGrid.ItemsSource = build;
        }
        private void BtnSortDown_Click(object sender, RoutedEventArgs e)
        {
            var build = _context.Itogs
                       .Include(c => c.BuildNavigation).
                       OrderByDescending(p => p.Price).ToList();
            BuildDataGrid.ItemsSource = build;
        }

        private void BtnResetFilter_Click(object sender, RoutedEventArgs e)
        {
            CmbFiltr.SelectedItem = null;
            LoadData();
        }
    }
}